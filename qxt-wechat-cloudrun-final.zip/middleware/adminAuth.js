/**
 * Admin Token 验证中间件
 * 通过请求头 Admin-Token 进行简单验证
 */

export function verifyAdminToken(request, reply, done) {
    const token = request.headers['admin-token'];
    // 生产环境建议与数据库中的真实Token对比
    if (!token) {
        return reply.status(401).send({ code: 401, message: '缺少管理员Token' });
    }
    // 简单的固定Token验证（后续改为数据库存储）
    if (token !== 'admin_token_2026_qxt') {
        return reply.status(403).send({ code: 403, message: 'Token无效' });
    }
    done();
}
