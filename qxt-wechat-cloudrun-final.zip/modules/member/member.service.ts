import { v4 as uuidv4 } from 'uuid'
import { getMemberInfo, setMemberInfo, deductMemberRemainCount, findUserByPhone } from '../../db/mockStore.js'

// 会员权益配置
export const MEMBER_PLANS = {
  0: {
    level: 0,
    name: '普通用户',
    price: 39.8,
    unit: '次',
    count: 1,
    period: null,
  },
  1: {
    level: 1,
    name: '季VIP',
    price: 198,
    unit: '季',
    count: 10,
    period: 3, // 月
  },
  2: {
    level: 2,
    name: '季SVIP',
    price: 598,
    unit: '季',
    count: 20,
    period: 3,
  },
  3: {
    level: 3,
    name: '黑金年卡',
    price: 2988,
    unit: '年',
    count: 50,
    period: 12,
  },
} as const

// 计算过期时间
export function calcExpireDate(level: number, fromDate: Date = new Date()): string {
  const plan = MEMBER_PLANS[level as keyof typeof MEMBER_PLANS]
  if (!plan || !plan.period) {
    // 单次购买，不过期（1年后）
    return new Date(fromDate.getTime() + 365 * 24 * 60 * 60 * 1000).toISOString()
  }
  const d = new Date(fromDate)
  d.setMonth(d.getMonth() + plan.period)
  return d.toISOString()
}

// 会员类型名称
export function getMemberTypeName(level: number): string {
  return MEMBER_PLANS[level as keyof typeof MEMBER_PLANS]?.name || '普通用户'
}

// 购买会员（Mock: 支付成功后直接开通）
export async function purchaseMember(phone: string, memberLevel: number, planId: string): Promise<any> {
  const plan = MEMBER_PLANS[memberLevel as keyof typeof MEMBER_PLANS]
  if (!plan) {
    return { success: false, error: '无效的会员等级' }
  }

  // 模拟支付流程（Mock直接成功）
  const orderId = uuidv4()
  const expireDate = calcExpireDate(memberLevel)

  // 更新用户会员等级
  const user = findUserByPhone(phone)
  if (user) {
    user.memberLevel = memberLevel
  }

  // 设置会员信息
  setMemberInfo(phone, {
    memberLevel,
    remainCount: plan.count,
    expireDate,
  })

  return {
    success: true,
    memberType: plan.name,
    remainCount: plan.count,
    expireDate,
    orderId,
  }
}

// 扣减次数
export async function deductMemberCount(phone: string): Promise<any> {
  let info = getMemberInfo(phone)

  // 如果没有会员信息，初始化为普通用户
  if (!info) {
    setMemberInfo(phone, {
      memberLevel: 0,
      remainCount: 0,
      expireDate: calcExpireDate(0),
    })
    info = getMemberInfo(phone)!
  }

  // 检查是否过期
  if (new Date(info!.expireDate) < new Date()) {
    // 已过期，重置为普通用户
    setMemberInfo(phone, {
      memberLevel: 0,
      remainCount: 0,
      expireDate: calcExpireDate(0),
    })
    info = getMemberInfo(phone)!
  }

  // 检查剩余次数
  if (info!.remainCount <= 0) {
    return {
      success: false,
      error: '剩余次数不足，请先购买会员',
      remainCount: 0,
    }
  }

  // 扣减次数
  deductMemberRemainCount(phone, 1)

  const updatedInfo = getMemberInfo(phone)!
  return {
    success: true,
    remainCount: updatedInfo.remainCount,
  }
}

// 查询会员状态
export async function getMemberStatus(phone: string): Promise<any> {
  let info = getMemberInfo(phone)

  // 如果没有会员信息，初始化为普通用户
  if (!info) {
    setMemberInfo(phone, {
      memberLevel: 0,
      remainCount: 0,
      expireDate: calcExpireDate(0),
    })
    info = getMemberInfo(phone)!
  }

  // 检查是否过期
  if (new Date(info!.expireDate) < new Date()) {
    // 已过期，重置为普通用户
    setMemberInfo(phone, {
      memberLevel: 0,
      remainCount: 0,
      expireDate: calcExpireDate(0),
    })
    info = getMemberInfo(phone)!
  }

  return {
    success: true,
    memberType: getMemberTypeName(info!.memberLevel),
    remainCount: info!.remainCount,
    expireDate: info!.expireDate,
    memberLevel: info!.memberLevel,
  }
}