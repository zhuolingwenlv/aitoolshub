/**
 * 微信支付服务 - JSAPI模式
 * 流程：统一下单 → 返回支付参数 → 小程序wx.requestPayment调起支付
 */
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CERT_DIR = path.join(__dirname, '../../certs');

// 微信支付配置（从环境变量读取）
const APPID = process.env.WECHAT_APPID || 'wxfd20b5775b2f6046';
const MCHID = process.env.WECHAT_MCHID || '1745479207';
const KEY = process.env.WECHAT_KEY || '1745479207'; // APIv2密钥（32位）
const APPSECRET = process.env.WECHAT_SECRET || '986d502b9e25f456b066c8f2f88f4e3d';

// 微信支付API地址
const WXPAY_API = 'https://api.mch.weixin.qq.com';
const NOTIFY_URL = process.env.WECHAT_NOTIFY_URL || 'https://qxt-backend-257487-7-1301487721.sh.run.tcloudbase.com/api/v1/member/pay-notify';

/**
 * 签名算法（MD5，微信V2接口）
 */
function sign(params, key) {
  const ks = Object.keys(params).filter(k => params[k] !== '' && params[k] !== null && params[k] !== undefined);
  ks.sort();
  const str = ks.map(k => `${k}=${params[k]}`).join('&') + `&key=${key}`;
  return crypto.createHash('md5').update(str, 'utf8').digest('hex').toUpperCase();
}

/**
 * 统一下单（JSAPI）- 获取小程序的支付参数
 * @param {string} openid - 用户openid
 * @param {string} orderId - 商户订单号
 * @param {string} body - 商品描述
 * @param {number} totalFee - 金额（分）
 * @param {string} planName - 套餐名称（用于attach）
 */
export async function unifiedOrder(openid, orderId, body, totalFee, planName) {
  const now = new Date();
  const timeStart = formatDate(now);
  const timeExpire = formatDate(new Date(now.getTime() + 25 * 60 * 1000)); // 25分钟有效期

  const params = {
    appid: APPID,
    mch_id: MCHID,
    nonce_str: randomStr(32),
    sign_type: 'MD5',
    body: body,
    out_trade_no: orderId,
    total_fee: totalFee, // 单位：分，必须整数
    spbill_create_ip: '127.0.0.1',
    time_start: timeStart,
    time_expire: timeExpire,
    notify_url: NOTIFY_URL,
    trade_type: 'JSAPI',
    openid: openid,
    attach: JSON.stringify({ planName, phone, mchid: MCHID }),
  };

  // 签名
  params.sign = sign(params, KEY);

  // 发送请求
  const xml = mapToXml(params);
  const response = await fetch(`${WXPAY_API}/pay/unifiedorder`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/xml; charset=utf-8' },
    body: xml,
  });

  const xmlText = await response.text();
  const result = xmlToMap(xmlText);

  if (result.return_code === 'FAIL') {
    throw new Error(`微信支付下单失败：${result.return_msg}`);
  }

  if (result.result_code === 'FAIL') {
    throw new Error(`业务失败：${result.err_code} - ${result.err_code_des}`);
  }

  // 构建小程序wx.requestPayment所需参数（调起支付）
  const timeStamp = Math.floor(Date.now() / 1000).toString();
  const nonceStr = randomStr(32);
  const prepayId = result.prepay_id;

  const payParams = {
    appId: APPID,
    timeStamp,
    nonceStr,
    package: `prepay_id=${prepayId}`,
    signType: 'MD5',
  };
  payParams.paySign = sign(payParams, KEY);

  return {
    success: true,
    orderId,
    prepayId,
    payParams, // 小程序wx.requestPayment直接用这个对象
  };
}

/**
 * 验证微信支付回调签名
 */
export function verifyNotifySign(params) {
  const signFromWx = params.sign;
  const mySign = sign(params, KEY);
  return signFromWx === mySign;
}

/**
 * 处理支付成功回调
 */
export async function processPayNotify(rawXml) {
  const params = xmlToMap(rawXml);

  if (params.return_code !== 'SUCCESS') {
    return { success: false, msg: '支付失败' };
  }

  // 验证签名
  if (!verifyNotifySign(params)) {
    console.error('微信支付回调签名验证失败');
    return { success: false, msg: '签名验证失败' };
  }

  const { out_trade_no, transaction_id, total_fee, attach } = params;
  let planName = '';
  try {
    planName = JSON.parse(attach || '{}').planName || '';
  } catch (e) {}

  console.log(`✅ 微信支付成功：订单号=${out_trade_no} 微信流水=${transaction_id} 金额=${totalFeeFenToYuan(total_fee)}元 套餐=${planName}`);

  return {
    success: true,
    orderId: out_trade_no,
    transactionId: transaction_id,
    planName,
  };
}

// ===== 工具函数 =====

function randomStr(len) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let s = '';
  for (let i = 0; i < len; i++) {
    s += chars[Math.floor(Math.random() * chars.length)];
  }
  return s;
}

function formatDate(d) {
  const pad = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

function mapToXml(params) {
  let xml = '<xml>';
  for (const [k, v] of Object.entries(params)) {
    xml += `<${k}><![CDATA[${v}]]></${k}>`;
  }
  xml += '</xml>';
  return xml;
}

function xmlToMap(xml) {
  const result = {};
  const matches = xml.matchAll(/<(\w+)><!\[CDATA\[([^\]]*)\]\]><\/\1>/g);
  for (const m of matches) {
    result[m[1]] = m[2];
  }
  return result;
}

function totalFeeFenToYuan(fen) {
  return (parseInt(fen) / 100).toFixed(2);
}
