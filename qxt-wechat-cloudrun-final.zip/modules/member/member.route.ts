import { FastifyInstance } from 'fastify'
import { purchaseMember, deductMemberCount, getMemberStatus, MEMBER_PLANS, getMemberTypeName, calcExpireDate } from './member.service.js'

export async function memberRoutes(fastify: FastifyInstance) {
  // 购买会员（POST /api/v1/member/purchase）
  // Mock实现：支付成功后直接开通，不调微信支付
  fastify.post('/purchase', {
    preHandler: [fastify.authenticate],
  }, async (request: any, reply) => {
    const { memberLevel, planId } = request.body as { memberLevel: number; planId: string }

    if (!MEMBER_PLANS[memberLevel as keyof typeof MEMBER_PLANS]) {
      return reply.status(400).send({ success: false, error: '无效的会员等级' })
    }

    const { phone } = request.user
    try {
      const result = await purchaseMember(phone, memberLevel, planId)
      return result
    } catch (err: any) {
      console.error('❌ 会员购买失败:', err)
      return reply.status(500).send({ success: false, error: '会员购买失败：' + err.message })
    }
  })

  // 扣减次数（POST /api/v1/member/deduct）
  // 每次生成报告前调用
  fastify.post('/deduct', {
    preHandler: [fastify.authenticate],
  }, async (request: any, reply) => {
    const { phone } = request.user

    try {
      const result = await deductMemberCount(phone)
      if (!result.success) {
        return reply.status(400).send(result)
      }
      return result
    } catch (err: any) {
      console.error('❌ 次数扣减失败:', err)
      return reply.status(500).send({ success: false, error: '次数扣减失败：' + err.message })
    }
  })

  // 查询会员状态（GET /api/v1/member/status）
  fastify.get('/status', {
    preHandler: [fastify.authenticate],
  }, async (request: any, reply) => {
    const { phone } = request.user

    try {
      const result = await getMemberStatus(phone)
      return result
    } catch (err: any) {
      console.error('❌ 查询会员状态失败:', err)
      return reply.status(500).send({ success: false, error: '查询会员状态失败：' + err.message })
    }
  })
}