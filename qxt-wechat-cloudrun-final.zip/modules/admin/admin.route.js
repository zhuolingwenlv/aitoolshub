import { getAdminUserList, getAdminUserDetail, updateMember, extendMember, giftCount, getAdminOrderList, getAdminOrderDetail, createRefund, getRefundStatus, getDashboardStats, getRevenueTrend, getUserTrend, getDisputeTypeDistribution } from './admin.service.js';
import { verifyAdminToken } from '../../middleware/adminAuth.js';
export default async function adminRoute(fastify) {
    // 所有路由需要管理员Token
    fastify.addHook('preHandler', verifyAdminToken);
    // ==================== 用户管理 ====================
    // GET /api/admin/users - 用户列表
    fastify.get('/users', async (request, reply) => {
        const { page = '1', pageSize = '20', phone, nickname, memberLevel, startDate, endDate } = request.query;
        const result = await getAdminUserList({
            page: parseInt(page),
            pageSize: parseInt(pageSize),
            phone, nickname, memberLevel, startDate, endDate
        });
        return reply.send({ code: 0, data: result });
    });
    // GET /api/admin/users/:id - 用户详情
    fastify.get('/users/:id', async (request, reply) => {
        const user = await getAdminUserDetail(request.params.id);
        if (!user)
            return reply.status(404).send({ code: 404, message: '用户不存在' });
        return reply.send({ code: 0, data: user });
    });
    // PUT /api/admin/users/:id/member - 手动修改会员
    fastify.put('/users/:id/member', async (request, reply) => {
        const { memberLevel, expireTime, reason } = request.body;
        await updateMember(request.params.id, { memberLevel, expireTime, reason });
        return reply.send({ code: 0, message: '会员更新成功' });
    });
    // POST /api/admin/users/:id/extend - 延长会员
    fastify.post('/users/:id/extend', async (request, reply) => {
        const { days, reason } = request.body;
        await extendMember(request.params.id, days, reason);
        return reply.send({ code: 0, message: `已延长${days}天` });
    });
    // POST /api/admin/users/:id/gift - 赠送梳理次数
    fastify.post('/users/:id/gift', async (request, reply) => {
        const { count, reason } = request.body;
        await giftCount(request.params.id, count, reason);
        return reply.send({ code: 0, message: `已赠送${count}次` });
    });
    // ==================== 订单管理 ====================
    // GET /api/admin/orders - 订单列表
    fastify.get('/orders', async (request, reply) => {
        const { page = '1', pageSize = '20', orderId, phone, productType, payStatus, startDate, endDate } = request.query;
        const result = await getAdminOrderList({
            page: parseInt(page),
            pageSize: parseInt(pageSize),
            orderId, phone, productType, payStatus, startDate, endDate
        });
        return reply.send({ code: 0, data: result });
    });
    // GET /api/admin/orders/:id - 订单详情
    fastify.get('/orders/:id', async (request, reply) => {
        const order = await getAdminOrderDetail(request.params.id);
        if (!order)
            return reply.status(404).send({ code: 404, message: '订单不存在' });
        return reply.send({ code: 0, data: order });
    });
    // POST /api/admin/orders/:id/refund - 发起退款
    fastify.post('/orders/:id/refund', async (request, reply) => {
        const { reason, operator } = request.body;
        await createRefund(request.params.id, reason, operator);
        return reply.send({ code: 0, message: '退款申请已提交' });
    });
    // GET /api/admin/orders/:id/refund - 退款状态
    fastify.get('/orders/:id/refund', async (request, reply) => {
        const status = await getRefundStatus(request.params.id);
        return reply.send({ code: 0, data: status });
    });
    // ==================== 仪表盘 ====================
    // GET /api/admin/dashboard/stats - 核心指标
    fastify.get('/dashboard/stats', async (_request, reply) => {
        const stats = await getDashboardStats();
        return reply.send({ code: 0, data: stats });
    });
    // GET /api/admin/dashboard/revenue - 收入趋势
    fastify.get('/dashboard/revenue', async (request, reply) => {
        const { days = '30' } = request.query;
        const data = await getRevenueTrend(parseInt(days));
        return reply.send({ code: 0, data });
    });
    // GET /api/admin/dashboard/users - 用户趋势
    fastify.get('/dashboard/users', async (request, reply) => {
        const { days = '30' } = request.query;
        const data = await getUserTrend(parseInt(days));
        return reply.send({ code: 0, data });
    });
    // GET /api/admin/dashboard/dispute-types - 纠纷类型分布
    fastify.get('/dashboard/dispute-types', async (_request, reply) => {
        const data = await getDisputeTypeDistribution();
        return reply.send({ code: 0, data });
    });
}
