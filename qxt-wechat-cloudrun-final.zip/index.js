import Fastify from 'fastify';
import cors from '@fastify/cors';
import jwt from '@fastify/jwt';
import staticFiles from '@fastify/static';
import path from 'path';
import { fileURLToPath } from 'url';
import { config } from './config/index.js';
import { evidenceRoutes } from './modules/evidence/evidence.route.js';
import { reportRoutes } from './modules/report/report.route.js';
import { userRoutes } from './modules/user/user.route.js';
import { verifyRoutes } from './modules/verify/verify.route.js';
import { memberRoutes } from './modules/member/member.route.js';
import adminRoutes from './modules/admin/admin.route.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = Fastify({ logger: true });

// CORS
await app.register(cors, { origin: true, credentials: true });

// 微信支付回调需要接收XML格式的原始body
app.addContentTypeParser('text/xml', { parseAs: 'string' }, (req, body, done) => { done(null, body); });
app.addContentTypeParser('application/xml', { parseAs: 'string' }, (req, body, done) => { done(null, body); });

// JWT
await app.register(jwt, { secret: config.jwt.secret });

// 全局装饰器：验证token
app.decorate('authenticate', async (request, reply) => {
    try { await request.jwtVerify(); }
    catch (err) { reply.status(401).send({ error: '未授权，请先登录' }); }
});

// 静态文件（容器内路径：/app）
const PROJECT_ROOT = '/app';

// PDF文件 /pdfs/*
const PDF_DIR = path.join(PROJECT_ROOT, 'public/pdfs');
await app.register(staticFiles, { root: PDF_DIR, prefix: '/pdfs', decorateReply: false });

// 管理后台HTML /
const PUBLIC_DIR = path.join(PROJECT_ROOT, 'public');
await app.get('/admin.html', async (_req, reply) => {
    const fs = await import('fs');
    const adminPath = path.join(PUBLIC_DIR, 'admin.html');
    try {
        const html = fs.readFileSync(adminPath, 'utf-8');
        return reply.type('text/html').send(html);
    } catch {
        return reply.status(404).send('admin.html not found');
    }
});

// 路由注册
await app.register(evidenceRoutes, { prefix: '/api/v1/evidence' });
await app.register(reportRoutes, { prefix: '/api/v1/report' });
await app.register(userRoutes, { prefix: '/api/v1/user' });
await app.register(verifyRoutes, { prefix: '/api/v1/verify' });
await app.register(memberRoutes, { prefix: '/api/v1/member' });
await app.register(adminRoutes, { prefix: '/api/v1/admin' });

// 健康检查
app.get('/health', async () => ({ status: 'ok', time: new Date().toISOString() }));

// 启动
const start = async () => {
    try {
        await app.listen({ port: config.port, host: config.host });
        console.log(`✅ 启信通后端已启动: http://${config.host}:${config.port}`);
    }
    catch (err) { app.log.error(err); process.exit(1); }
};
start();
